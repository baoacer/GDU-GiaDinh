-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chat_app
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `recipients` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1090 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1060,'SERVER',NULL,'An has joined the chat!','2024-11-08 14:52:01'),(1061,'SERVER',NULL,'An','2024-11-08 14:52:01'),(1062,'An',NULL,'asdasdsa','2024-11-08 14:52:45'),(1063,'An',NULL,'d1d1d','2024-11-08 14:52:54'),(1064,'SERVER',NULL,'dắc has joined the chat!','2024-11-08 14:53:08'),(1065,'SERVER',NULL,'An,dắc','2024-11-08 14:53:08'),(1066,'SERVER',NULL,'thienan has joined the chat!','2024-11-08 14:53:14'),(1067,'SERVER',NULL,'thienan,An,dắc','2024-11-08 14:53:14'),(1068,'dắc','An','Chào em','2024-11-08 14:53:28'),(1069,'dắc','thienan','Chao thien an','2024-11-08 14:53:35'),(1070,'thienan',NULL,'d1d1d1d1d1','2024-11-08 14:53:44'),(1071,'dắc',NULL,'Client dắc disconnected ','2024-11-08 14:57:58'),(1072,'SERVER',NULL,'thienan,An','2024-11-08 14:57:58'),(1073,'An',NULL,'Client An disconnected ','2024-11-08 15:04:44'),(1074,'SERVER',NULL,'thienan','2024-11-08 15:04:44'),(1075,'SERVER',NULL,'','2024-11-08 15:11:48'),(1076,'SERVER',NULL,'client1 has joined the chat!','2024-11-08 15:28:26'),(1077,'SERVER',NULL,'client1','2024-11-08 15:28:26'),(1078,'SERVER',NULL,'client2 has joined the chat!','2024-11-08 15:28:36'),(1079,'SERVER',NULL,'client2,client1','2024-11-08 15:28:36'),(1080,'SERVER',NULL,'client3 has joined the chat!','2024-11-08 15:28:43'),(1081,'SERVER',NULL,'client3,client2,client1','2024-11-08 15:28:43'),(1082,'client2',NULL,'Xin Chào mọi người','2024-11-08 15:30:08'),(1083,'client3','client1','Xin chào client 1','2024-11-08 15:31:03'),(1084,'client2',NULL,'Client client2 disconnected ','2024-11-08 15:31:27'),(1085,'SERVER',NULL,'client3,client1','2024-11-08 15:31:27'),(1086,'client3',NULL,'Client client3 disconnected ','2024-11-08 15:32:06'),(1087,'SERVER',NULL,'client1','2024-11-08 15:32:06'),(1088,'client1',NULL,'Client client1 disconnected ','2024-11-08 15:32:07'),(1089,'SERVER',NULL,'','2024-11-08 15:32:07');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-08 18:51:37
