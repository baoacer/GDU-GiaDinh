package controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import model.Message;
import view.ChatView;

import java.util.*;

import client.ChatClient;

public class ChatController {
	private ChatView chatView;
	private ChatClient chatClient;
	private ObservableList<String> onlineUsers = FXCollections.observableArrayList();
	private List<String> selectedRecipients = null; // null means send to all
	private String username;

	public ChatController() {

	}

	public ChatController(ChatView view) {
		this.chatView = view;
	}

	public void connect(String username) {
		this.username = username;
		chatClient = new ChatClient(username, "localhost", 5000, this);
	}

	public void handleMessage(Message message) {
		Platform.runLater(() -> {
			switch (message.getType()) {
			case USER_LIST:
				String[] users = message.getContent().split(",");
				onlineUsers.setAll(users);
				chatView.updateUserList(onlineUsers);
				break;
			case MESSAGE:
				String displayMessage = message.getSender()
						+ (message.getRecipients() == null ? " (to all)" : " (private)") + ": " + message.getContent();
				chatView.appendMessage(displayMessage);
				break;
			case DISCONNECT:
				String disconnectMessage = message.getContent();
				chatView.appendMessage(disconnectMessage);
				break;
			}

		});
	}

	public void sendMessage(String content) {
		// Nếu selectedRecipients là null, gửi cho tất cả
		Message message = new Message(username, selectedRecipients, content, Message.MessageType.MESSAGE);
		chatClient.sendMessage(message);
	}

	public void setSelectedRecipients(List<String> recipients) {
		// null means send to all
		this.selectedRecipients = recipients;
	}

	public void disconnect() {
		chatClient.disconnect();
	}
}