package client;

import model.Message;
import java.io.*;
import java.net.*;
import java.util.*;

import controller.ChatController;

public class ChatClient {
	private String username;
	private Socket socket;
	private ObjectOutputStream output; // Luồng để gửi dữ liệu đến server
	private ObjectInputStream input; // Luồng để nhận dữ liệu từ server
	private ChatController controller; // Đối tượng controller để quản lý giao diện chat và xử lý tin nhắn

	public ChatClient(String username, String host, int port, ChatController controller) {
		this.username = username;
		this.controller = controller;
		try {
			// Tạo kết nối đến server qua host và port được cung cấp
			socket = new Socket(host, port);
			output = new ObjectOutputStream(socket.getOutputStream()); // Khởi tạo luồng xuất để gửi tin nhắn (Gữi dữ
																		// liệu đi)
			input = new ObjectInputStream(socket.getInputStream()); // Khởi tạo luồng nhập để nhận tin nhắn (Nhận dữ
																	// liệu được gữi)

			
			// Tạo và gửi tin nhắn kết nối đến server
			Message connectMessage = new Message(username, null, "connected", Message.MessageType.CONNECT);
			
			sendMessage(connectMessage);

			// Khởi chạy một luồng mới để lắng nghe các tin nhắn từ server
			new Thread(this::listenForMessages).start();
		} catch (IOException e) {
			e.printStackTrace();// Xử lý lỗi khi kết nối tới server thất bại
		}
	}

	// Lắng nghe xem có Tin nhắn nào không, để nó hiện lên cái Client của nó
	private void listenForMessages() {
		try {
			// Liên tục đọc, đọc hoài lun
			while (!socket.isClosed()) { // Kiểm tra xem socket có đóng không
				try {
					// Đọc tin nhắn từ luồng nhập (server gửi)
					Message message = (Message) input.readObject();
					// Đọc xong rồi đưa qua cho controller xử lí
					controller.handleMessage(message);
				} catch (EOFException | SocketException e) {
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Phương thức gửi tin nhắn đến server
	public void sendMessage(Message message) {
		try {
			output.writeObject(message); // Ghi đối tượng tin nhắn vào luồng xuất, luồng gữi dữ liệu đi
			output.flush(); // Đẩy dữ liệu đi ngay
		} catch (IOException e) {
			e.printStackTrace(); // Xử lý lỗi khi gửi tin nhắn
		}
	}

	public void disconnect() {
		try {
			// Gửi tin nhắn ngắt kết nối đến server
			Message disconnectMessage = new Message(username, null, "Client " + username + " disconnected ",
					Message.MessageType.DISCONNECT);
			sendMessage(disconnectMessage);

			// Đóng các luồng và socket
			if (input != null)
				input.close();
			if (output != null)
				output.close();
			if (socket != null && !socket.isClosed())
				socket.close();

			System.out.println("Ngắt kết nối thành công.");
			
		} catch (IOException e) {
			e.printStackTrace(); // Xử lý lỗi khi ngắt kết nối
		}
	}

	public String getUsername() {
		return username;
	}

}