package view;

import java.util.List;
import java.util.stream.Collectors;

import controller.ChatController;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ChatView extends Application {
	private ChatController controller;
	private TextArea chatArea;
	private TextField messageField;
	private ListView<String> userList;
	private Button sendButton;
	private CheckBox sendToAllCheckBox;

	@Override
	public void start(Stage primaryStage) {
		controller = new ChatController(this);

		buildComponent(primaryStage);
		setEvent();
	}

	/**
	 * @param primaryStage
	 */
	private void buildComponent(Stage primaryStage) {
		BorderPane root = new BorderPane();
		// Chat area
		chatArea = new TextArea();
		chatArea.setEditable(false);
		chatArea.setWrapText(true);

		// User list with header
		userList = new ListView<>();
		userList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		userList.setPrefWidth(150);

		// Send to all checkbox
		sendToAllCheckBox = new CheckBox("Send to All");
		sendToAllCheckBox.setSelected(false);// mặc định ko chọn

		// Message input area
		HBox inputBox = new HBox(10);
		messageField = new TextField();
		sendButton = new Button("Send");
		inputBox.getChildren().addAll(messageField, sendButton);

		// Right panel with user list and send to all option
		VBox rightPanel = new VBox(10);
		rightPanel.getChildren().addAll(new Label("Recipients:"), sendToAllCheckBox, userList);
		rightPanel.setPadding(new Insets(10));

		root.setCenter(chatArea);
		root.setRight(rightPanel);
		root.setBottom(inputBox);
		BorderPane.setMargin(inputBox, new Insets(10));

		// Hiển thị dialog đăng nhập
		String username = showLoginDialog(); // Lấy username từ phương thức login
		if (username != null) {
			controller.connect(username);
			primaryStage.setTitle("Chat - " + username);
		}

		Scene scene = new Scene(root, 500, 450);
		primaryStage.setScene(scene);
		primaryStage.show();

		// Xử lý khi đóng cửa sổ
		primaryStage.setOnCloseRequest(e -> controller.disconnect());
	}

	private void setEvent() {
		// Xử lý sự kiện nhấn nút
		sendButton.setOnAction(e -> sendMessage());

		messageField.setOnAction(e -> sendMessage());

		// Xử lý sự kiện chọn người nhận
		userList.getSelectionModel().selectedItemProperty().addListener((obs, old, newVal) -> {
			if (!sendToAllCheckBox.isSelected()) {
				List<String> selectedUsers = userList.getSelectionModel().getSelectedItems().stream()
						.collect(Collectors.toList());
				controller.setSelectedRecipients(selectedUsers);
			}
		});

		// Xử lý sự kiện checkbox Send to All
		sendToAllCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> {
			userList.setDisable(newVal); // Disable user list khi chọn Send to All
			if (newVal) {
				userList.getSelectionModel().clearSelection();
				controller.setSelectedRecipients(null); // null đại diện cho gửi tất cả
			}
		});

	}

	private String showLoginDialog() {
		final String[] username = new String[1]; // Sử dụng mảng để thay đổi giá trị bên trong lambda
		boolean[] isValid = { false }; // Tương tự sử dụng mảng để quản lý trạng thái hợp lệ

		while (!isValid[0]) { // Vòng lặp tiếp tục cho đến khi username hợp lệ
			TextInputDialog dialog = new TextInputDialog();
			dialog.setTitle("Login");
			dialog.setHeaderText("Enter your username:");

			dialog.showAndWait().ifPresent(input -> {
				if (!input.isEmpty()) {
					username[0] = input; // Gán username từ người dùng
					isValid[0] = true; // Đặt trạng thái hợp lệ
				} else {
					Alert alert = new Alert(Alert.AlertType.ERROR);
					alert.setTitle("Error");
					alert.setHeaderText("Username cannot be empty!");
					alert.setContentText("Please enter a valid username.");
					alert.showAndWait();
				}
			});

			// Kiểm tra nếu người dùng nhấn "Cancel" hoặc không nhập tên
			if (dialog.getResult() == null || dialog.getResult().isEmpty()) {
				System.exit(0); // Thoát chương trình nếu người dùng không nhập tên
			}
		}
		return username[0]; // Trả về giá trị username
	}

	public void appendMessage(String message) {
		chatArea.appendText(message + "\n");
	}

	public void updateUserList(ObservableList<String> users) {
		userList.setItems(users);
	}

	private void sendMessage() {
		String content = messageField.getText().trim();
		if (!content.isEmpty()) {
			controller.sendMessage(content);
			messageField.clear();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
