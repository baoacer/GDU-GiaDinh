package server;

import model.Message;
import model.Message.MessageType;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import database.DatabaseConnection;

//Khởi tạo server và lắng nghe kết nối từ client
//Quản lý danh sách các client hiện tại
//Gửi và nhận tin nhắn từ các client
//Cập nhật cơ sở dữ liệu với tin nhắn và thông tin kết nối
public class Server {
	private ServerSocket serverSocket; // ServerSocket dùng để chấp nhận kết nối từ các client
	private Map<String, ClientHandler> clients = new ConcurrentHashMap<>(); // Danh sách các client hiện tại

	public Server(int port) {
		try {
			serverSocket = new ServerSocket(port); // Khi tạo đối tượng, cần truyền vào PORT mà server sẽ chạy
			System.out.println("Server started on port " + port); // Hiển thị thông báo khởi động server
		} catch (IOException e) {
			e.printStackTrace(); // Xử lý lỗi nếu không thể tạo ServerSocket
		}
	}

	private void startServer() {
		// Liên tục chạy, chờ kết nối từ client
		while (true) {
			try {
				Socket socket = serverSocket.accept(); // Chấp nhận kết nối từ client
				ClientHandler clientHandler = new ClientHandler(socket, this); // Tạo handler cho client mới

				new Thread(clientHandler).start(); // Chạy handler trong một luồng mới
			} catch (IOException e) {
				e.printStackTrace(); // Xử lý lỗi khi chấp nhận kết nối
			}
		}
	}

	public void broadcast(Message message) {
		   saveMessage(message);

		if (message.getRecipients() == null || message.getRecipients().isEmpty()) {
			if (message.getType() == MessageType.MESSAGE) {
				System.out.println("Gửi tin nhắn đến tất cả client: " + message.getContent());
			} else if (message.getType() == MessageType.USER_LIST) {
				System.out.println("Cập nhật danh sách người dùng đến tất cả client.");
			}

			for (ClientHandler client : clients.values()) {
				client.sendMessage(message);
			}
		} else {

			// Gửi tin nhắn đến các client cụ thể
			System.out.print("Gửi tin nhắn đến: ");
			for (String recipient : message.getRecipients()) {
				ClientHandler client = clients.get(recipient);
				if (client != null) {
					client.sendMessage(message);
					System.out.print(recipient + " "); // In ra tên của từng người nhận
				}
			}
			System.out.println(); // Xuống dòng sau khi in danh sách người nhận
		}
	}

	// Thêm client vào server và cơ sở dữ liệu
	public void addClient(String username, ClientHandler handler) {
		// Thêm client vào danh sách server
		clients.put(username, handler);

		// Gửi thông báo cho tất cả client còn lại khi có người mới vào chat
		String joinMessage = username + " has joined the chat!";
		Message joinNotification = new Message("SERVER", null, joinMessage, Message.MessageType.MESSAGE);
		broadcast(joinNotification); // Gửi thông báo này tới tất cả các client

		// Cập nhật danh sách người dùng và gửi cho tất cả client
		List<String> userList = new ArrayList<>(clients.keySet());
		Message userListMessage = new Message("SERVER", null, String.join(",", userList),
				Message.MessageType.USER_LIST);
		broadcast(userListMessage);
	}

	// Xóa client khi ngắt kết nối
	public void removeClient(String username) {
		// Xóa client khỏi danh sách server
		clients.remove(username);

		// Cập nhật danh sách người dùng và gửi cho tất cả client
		List<String> userList = new ArrayList<>(clients.keySet());
		Message userListMessage = new Message("SERVER", null, String.join(",", userList),
				Message.MessageType.USER_LIST);
		broadcast(userListMessage);

	}
	
	private void saveMessage(Message message) {
	    String sql = "INSERT INTO messages (sender, recipients, content, timestamp) VALUES (?, ?, ?, ?)";

	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        String sender = message.getSender();
	        // Kiểm tra nếu recipients là null hoặc danh sách rỗng thì để recipient là null
	        String recipients = (message.getRecipients() != null && !message.getRecipients().isEmpty()) 
	                            ? String.join(",", message.getRecipients()) 
	                            : null;
	        String content = message.getContent() != null ? message.getContent() : "";

	        pstmt.setString(1, sender);
	        pstmt.setString(2, recipients);  // Lưu người nhận vào đúng cột recipients
	        pstmt.setString(3, content);     // Lưu nội dung vào đúng cột content
	        pstmt.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));

	        pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	public static void main(String[] args) {
		new Server(5000).startServer(); // Khởi động server tại port 5000
	}
}
