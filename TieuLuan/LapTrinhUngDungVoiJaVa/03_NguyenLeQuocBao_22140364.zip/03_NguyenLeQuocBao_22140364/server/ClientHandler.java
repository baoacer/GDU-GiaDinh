package server;

import model.Message;
import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
	private Socket socket;
	private Server server;
	private ObjectInputStream input;
	private ObjectOutputStream output;
	private String username;
	private volatile boolean isConnected = true;

	public ClientHandler(Socket socket, Server server) {
		this.socket = socket;
		this.server = server;
		try {
			output = new ObjectOutputStream(socket.getOutputStream());
			input = new ObjectInputStream(socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		try {
			// Đọc thông tin người dùng khi mới kết nối
			Message connectMessage = (Message) input.readObject();
			this.username = connectMessage.getSender();
			server.addClient(username, this);
			System.out.println("Client connected: " + username);

			while (isConnected) {
				try {
					// Đọc tin nhắn từ client và gửi cho server
					Message message = (Message) input.readObject();
					System.out.println("Received message from " + message.getSender() + ": " + message.getContent());
					server.broadcast(message);
				} catch (IOException | ClassNotFoundException e) {
					isConnected = false;  // Nếu gặp lỗi, thoát vòng lặp
				}
			}
		} catch (Exception e) {
			System.out.println("Error with client " + username);
		} finally {
			// Đảm bảo xóa client khi ngắt kết nối
			server.removeClient(username);
			closeConnection();
		}
	}

	private void closeConnection() {
		try {
			if (input != null) input.close();
			if (output != null) output.close();
			if (socket != null && !socket.isClosed()) socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMessage(Message message) {
		try {
			output.writeObject(message);
			output.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
