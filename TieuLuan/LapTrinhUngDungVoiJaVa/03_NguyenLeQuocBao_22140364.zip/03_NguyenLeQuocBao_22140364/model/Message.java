package model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class Message implements Serializable {
	private String sender; // Người gửi
	private List<String> recipients; // Người nhận (null = gửi cho tất cả)
	private String content; // Nội dung tin nhắn
	private MessageType type; // Loại tin nhắn

	public enum MessageType implements Serializable {
		CONNECT, // Kết nối mới
		DISCONNECT, // Ngắt kết nối
		MESSAGE, // Tin nhắn thông thường
		USER_LIST // Cập nhật danh sách user
	}

	// Constructor
	public Message(String sender, List<String> recipients, String content, MessageType type) {
		this.sender = sender;
		this.recipients = recipients;
		this.content = content;
		this.type = type;
	}

	// Getters
	public String getSender() {
		return sender;
	}

	public List<String> getRecipients() {
		return recipients;
	}

	public String getContent() {
		return content;
	}

	public MessageType getType() {
		return type;
	}
}