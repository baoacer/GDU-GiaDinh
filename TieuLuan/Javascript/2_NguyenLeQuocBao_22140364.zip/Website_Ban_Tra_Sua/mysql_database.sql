	-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
	--
	-- Host: 127.0.0.1    Database: fastfoodorder_v2
	-- ------------------------------------------------------
	-- Server version	9.0.1
	
	-- Table structure for table `Orders`
	--

	DROP TABLE IF EXISTS `Orders`;
	CREATE TABLE `Orders` (
	  `orderId` int NOT NULL AUTO_INCREMENT,
	  `status` enum('InProgress','Resolved','Closed') NOT NULL DEFAULT 'InProgress',
	  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `userId` int NOT NULL,
	  PRIMARY KEY (`orderId`),
	  KEY `FK_cc257418e0228f05a8d7dcc5553` (`userId`),
	  CONSTRAINT `FK_cc257418e0228f05a8d7dcc5553` FOREIGN KEY (`userId`) REFERENCES `Users` (`userId`)
	) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


	--
	-- Dumping data for table `Orders`
	--

	LOCK TABLES `Orders` WRITE;
	INSERT INTO `Orders` VALUES (1,'InProgress','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',1),(2,'Resolved','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',1),(3,'Closed','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',1),(4,'InProgress','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',2),(5,'Resolved','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',2),(6,'Closed','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',2),(7,'InProgress','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',3),(8,'Resolved','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',3),(9,'Closed','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',3),(10,'InProgress','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',4),(11,'Resolved','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',4),(12,'Closed','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',4),(13,'InProgress','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',5),(14,'Resolved','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',5),(15,'Closed','2024-11-06 11:42:23.264851','2024-11-06 11:42:23.264851',5),(16,'InProgress','2024-11-06 13:19:34.385404','2024-11-06 13:19:34.385404',7),(17,'InProgress','2024-11-06 21:44:25.835000','2024-11-06 21:44:25.835000',8);
	UNLOCK TABLES;

	--
	-- Table structure for table `OrdersItems`
	--

	DROP TABLE IF EXISTS `OrdersItems`;
	CREATE TABLE `OrdersItems` (
	  `orderItemID` int NOT NULL AUTO_INCREMENT,
	  `quantity` int NOT NULL,
	  `amount` decimal(10,2) NOT NULL,
	  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `orderId` int DEFAULT NULL,
	  `productId` int DEFAULT NULL,
	  `productSizeId` int DEFAULT NULL,
	  PRIMARY KEY (`orderItemID`),
	  KEY `FK_36f3cd86110d679981dd610f3cc` (`orderId`),
	  KEY `FK_a5292debd7134ca9e606420ce08` (`productId`),
	  KEY `FK_35b48086f2d908c7319fc80968f` (`productSizeId`),
	  CONSTRAINT `FK_35b48086f2d908c7319fc80968f` FOREIGN KEY (`productSizeId`) REFERENCES `ProductSizes` (`productSizeId`) ON DELETE CASCADE,
	  CONSTRAINT `FK_36f3cd86110d679981dd610f3cc` FOREIGN KEY (`orderId`) REFERENCES `Orders` (`orderId`) ON DELETE CASCADE,
	  CONSTRAINT `FK_a5292debd7134ca9e606420ce08` FOREIGN KEY (`productId`) REFERENCES `Products` (`productID`) ON DELETE CASCADE
	) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

	--
	-- Dumping data for table `OrdersItems`
	--

	LOCK TABLES `OrdersItems` WRITE;
	INSERT INTO `OrdersItems` VALUES (31,2,60000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,1,1),(32,1,35000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,2,2),(33,2,70000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,3,3),(34,1,32000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,4,1),(35,3,105000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,5,2),(36,2,80000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',1,6,3),(37,1,30000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,7,1),(38,2,75000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,8,2),(39,3,120000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,9,3),(40,1,40000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,10,1),(41,2,70000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,11,2),(42,1,33000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',2,12,3),(43,2,68000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,13,1),(44,3,110000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,14,2),(45,1,36000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,15,3),(46,2,64000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,16,1),(47,1,37000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,17,2),(48,2,86000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',3,18,3),(49,3,93000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,19,1),(50,1,32000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,20,2),(51,2,90000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,21,3),(52,3,105000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,22,1),(53,1,35000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,23,2),(54,2,80000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',4,24,3),(55,2,70000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,25,1),(56,3,120000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,26,2),(57,1,42000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,27,3),(58,2,66000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,28,1),(59,3,99000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,29,2),(60,1,37000.00,'2024-11-06 11:42:31.255617','2024-11-06 11:42:31.255617',5,30,3),(61,22,770000.00,'2024-11-06 13:19:34.420357','2024-11-06 13:19:34.420357',16,14,2),(62,4,140000.00,'2024-11-06 13:19:34.440899','2024-11-06 13:19:34.440899',16,26,2),(63,22,770000.00,'2024-11-06 21:44:25.875000','2024-11-06 21:44:25.875000',17,14,2),(64,4,140000.00,'2024-11-06 21:44:25.879000','2024-11-06 21:44:25.879000',17,26,2);
	UNLOCK TABLES;

	--
	-- Table structure for table `ProductSizes`
	--

	DROP TABLE IF EXISTS `ProductSizes`;
	CREATE TABLE `ProductSizes` (
	  `productSizeId` int NOT NULL AUTO_INCREMENT,
	  `size` enum('Small','Medium','Large') NOT NULL,
	  `price` decimal(10,2) NOT NULL,
	  `productId` int DEFAULT NULL,
	  PRIMARY KEY (`productSizeId`),
	  KEY `FK_c5466793192348737c0a19309cc` (`productId`),
	  CONSTRAINT `FK_c5466793192348737c0a19309cc` FOREIGN KEY (`productId`) REFERENCES `Products` (`productID`)
	) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

	--
	-- Dumping data for table `ProductSizes`
	--

	LOCK TABLES `ProductSizes` WRITE;
	/*!40000 ALTER TABLE `ProductSizes` DISABLE KEYS */;
	INSERT INTO `ProductSizes` VALUES
	(1,'Small',30000.00,1),
	(2,'Medium',35000.00,1),
	(3,'Large',40000.00,1),
	(4,'Small',32000.00,2),
	(5,'Medium',37000.00,2),
	(6,'Large',42000.00,2),
	(7,'Small',31000.00,3),
	(8,'Medium',36000.00,3),(9,'Large',41000.00,3),(10,'Small',30000.00,4),(11,'Medium',35000.00,4),(12,'Large',40000.00,4),(13,'Small',33000.00,5),(14,'Medium',38000.00,5),(15,'Large',43000.00,5),(16,'Small',31000.00,6),(17,'Medium',36000.00,6),(18,'Large',41000.00,6),(19,'Small',32000.00,7),(20,'Medium',37000.00,7),(21,'Large',42000.00,7),(22,'Small',33000.00,8),(23,'Medium',38000.00,8),(24,'Large',43000.00,8),(25,'Small',31000.00,9),(26,'Medium',36000.00,9),(27,'Large',41000.00,9),(28,'Small',30000.00,10),(29,'Medium',35000.00,10),(30,'Large',40000.00,10),(31,'Small',32000.00,11),(32,'Medium',37000.00,11),(33,'Large',42000.00,11),(34,'Small',33000.00,12),(35,'Medium',38000.00,12),(36,'Large',43000.00,12),(37,'Small',30000.00,13),(38,'Medium',35000.00,13),(39,'Large',40000.00,13),(40,'Small',31000.00,14),(41,'Medium',36000.00,14),(42,'Large',41000.00,14),(43,'Small',32000.00,15),(44,'Medium',37000.00,15),(45,'Large',42000.00,15),(46,'Small',33000.00,16),(47,'Medium',38000.00,16),(48,'Large',43000.00,16),(49,'Small',30000.00,17),(50,'Medium',35000.00,17),(51,'Large',40000.00,17),(52,'Small',31000.00,18),(53,'Medium',36000.00,18),(54,'Large',41000.00,18),(55,'Small',32000.00,19),(56,'Medium',37000.00,19),(57,'Large',42000.00,19),(58,'Small',33000.00,20),(59,'Medium',38000.00,20),(60,'Large',43000.00,20),(61,'Small',30000.00,21),(62,'Medium',35000.00,21),(63,'Large',40000.00,21),(64,'Small',32000.00,22),(65,'Medium',37000.00,22),(66,'Large',42000.00,22),(67,'Small',33000.00,23),(68,'Medium',38000.00,23),(69,'Large',43000.00,23),(70,'Small',31000.00,24),(71,'Medium',36000.00,24),(72,'Large',41000.00,24),(73,'Small',30000.00,25),(74,'Medium',35000.00,25),(75,'Large',40000.00,25),(76,'Small',32000.00,26),(77,'Medium',37000.00,26),(78,'Large',42000.00,26),(79,'Small',33000.00,27),(80,'Medium',38000.00,27),(81,'Large',43000.00,27),(82,'Small',31000.00,28),(83,'Medium',36000.00,28),(84,'Large',41000.00,28),(85,'Small',30000.00,29),(86,'Medium',35000.00,29),(87,'Large',40000.00,29),(88,'Small',32000.00,30),(89,'Medium',37000.00,30),(90,'Large',42000.00,30);
	UNLOCK TABLES;

	--
	-- Table structure for table `Products`
	--

	DROP TABLE IF EXISTS `Products`;
	CREATE TABLE `Products` (
	  `productID` int NOT NULL AUTO_INCREMENT,
	  `productName` varchar(255) NOT NULL,
	  `description` varchar(255) DEFAULT NULL,
	  `imageURL` varchar(255) DEFAULT NULL,
	  `isActive` tinyint NOT NULL DEFAULT '1',
	  PRIMARY KEY (`productID`)
	) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

	UPDATE Products
	SET productName = 'luc_tra_hoang_kim_4b2ef28d7cc04db0a47c0587e05f8963_large.webp'
	WHERE productID = 3;



	--
	-- Dumping data for table `Products`
	--
	LOCK TABLES `Products` WRITE;
	INSERT INTO `Products` VALUES 
	(1,'Trà sữa trân châu đường đen','Trà sữa truyền thống với trân châu đường đen','luc_tra_hoang_kim_4b2ef28d7cc04db0a47c0587e05f8963_large.webp',1),
	(2,'Trà sữa matcha','Trà sữa với hương vị matcha','oolong_tanbei_latte_61e58f8d2b144fa1976d3b78504248b6_large.webp',1),
	(3,'Trà sữa hồng trà','Trà sữa với hương vị hồng trà','luc_tra_hoang_kim_4b2ef28d7cc04db0a47c0587e05f8963_large.webp',1),
	(4,'Trà sữa dâu','Trà sữa với vị dâu tươi','ts_comebuy_cf2fd6cf2b364ee491596767618ca054_large.webp',1),
	(5,'Trà sữa khoai môn','Trà sữa với vị khoai môn','ts_hai_than_66599a9e451c47a9a637b41d0289d21c_large.webp',1),
	(6,'Trà sữa vị socola','Trà sữa với vị socola','ts_hoa_hong_2f70697d2f184df89a183976680f9ea3_large.webp',1),
	(7,'Trà sữa bạc hà','Trà sữa với vị bạc hà','ts_hong_kong_ea8bda8a4b874fc5a118c8170f683915_large.webp',1),
	(8,'Trà sữa trái cây nhiệt đới','Trà sữa với các loại trái cây nhiệt đới','ts_mat_ong_09df102f64f74405bf0a495dd8bb073d_large.webp',1),
	(9,'Trà sữa sữa dừa','Trà sữa với vị sữa dừa','ts_mat_ong_b133c021324548d0ad3dc1b87524897f_large.webp',1),
	(10,'Trà sữa mật ong','Trà sữa vị mật ong ngọt ngào','ts_signature_da473adc7fcc4d1d8c4d6378adc1f114_large.webp',1),
	(11,'Trà sữa ô long','Trà sữa với vị ô long','ts_suong_sao_c5f9f21a549543f89ec8fa2a74885b41_large.webp',1),
	(12,'Trà sữa matcha đậu đỏ','Trà sữa matcha với đậu đỏ','ts_tran_chau_052aed385e41470db7cec46eddfcfdbb_large.webp',1),
	(13,'Trà sữa tiramisu','Trà sữa với hương vị tiramisu','tra_hai_than_latte_d71f90e78c38459c9d0bcacc6063c1b9_large.webp',1),
	(14,'Trà sữa việt quất','Trà sữa vị việt quất','oolong_tanbei_latte_61e58f8d2b144fa1976d3b78504248b6_large.webp',1),
	(15,'Trà sữa trà xanh','Trà sữa với vị trà xanh','ts_hai_than_66599a9e451c47a9a637b41d0289d21c_large.webp',1),
	(16,'Trà sữa bạc hà chanh','Trà sữa vị bạc hà chanh','ts_mat_ong_b133c021324548d0ad3dc1b87524897f_large.webp',1),
	(17,'Trà sữa caramel','Trà sữa vị caramel','ts_hai_than_66599a9e451c47a9a637b41d0289d21c_large.webp',1),
	(18,'Trà sữa chanh leo','Trà sữa vị chanh leo','ts_suong_sao_c5f9f21a549543f89ec8fa2a74885b41_large.webp',1),
	(19,'Trà sữa hạt chia','Trà sữa với hạt chia','ts_hong_kong_ea8bda8a4b874fc5a118c8170f683915_large.webp',1),
	(20,'Trà sữa nha đam','Trà sữa với nha đam','ts_suong_sao_c5f9f21a549543f89ec8fa2a74885b41_large.webp',1),
	(21,'Trà sữa đào','Trà sữa vị đào tươi','ts_hong_kong_ea8bda8a4b874fc5a118c8170f683915_large.webp',1),
	(22,'Trà sữa sô cô la bạc hà','Trà sữa sô cô la bạc hà','ts_mat_ong_b133c021324548d0ad3dc1b87524897f_large.webp',1),
	(23,'Trà sữa chanh dây','Trà sữa chanh dây','ts_hoa_hong_2f70697d2f184df89a183976680f9ea3_large.webp',1),
	(24,'Trà sữa bưởi hồng','Trà sữa vị bưởi hồng','tra_hai_than_latte_d71f90e78c38459c9d0bcacc6063c1b9_large.webp',1),
	(25,'Trà sữa khoai môn nướng','Trà sữa vị khoai môn nướng','oolong_tanbei_latte_61e58f8d2b144fa1976d3b78504248b6_large.webp',1),
	(26,'Trà sữa xoài','Trà sữa vị xoài','ts_mat_ong_09df102f64f74405bf0a495dd8bb073d_large.webp',1),
	(27,'Trà sữa cam','Trà sữa vị cam','ts_hai_than_66599a9e451c47a9a637b41d0289d21c_large.webp',1),
	(28,'Trà sữa kiwi','Trà sữa vị kiwi','ts_hai_than_66599a9e451c47a9a637b41d0289d21c_large.webp',1),
	(29,'Trà sữa dưa lưới','Trà sữa vị dưa lưới','tra_hai_than_latte_d71f90e78c38459c9d0bcacc6063c1b9_large.webp',1),
	(30,'Trà sữa chuối','Trà sữa vị chuối','ts_suong_sao_c5f9f21a549543f89ec8fa2a74885b41_large.webp',1);
	UNLOCK TABLES;


	--
	-- Table structure for table `Users`
	--

	DROP TABLE IF EXISTS `Users`;
	CREATE TABLE `Users` (
	  `userId` int NOT NULL AUTO_INCREMENT,
	  `email` varchar(255) NOT NULL,
	  `password` varchar(255) NOT NULL,
	  `phoneNumber` varchar(255) NOT NULL,
	  `address` varchar(255) DEFAULT NULL,
	  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
	  `isAdmin` tinyint NOT NULL DEFAULT '0',
	  `refreshToken` varchar(255) DEFAULT NULL,
	  `fullname` varchar(255) DEFAULT NULL,
	  PRIMARY KEY (`userId`)
	) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

	--
	-- Dumping data for table `Users`
	--

	LOCK TABLES `Users` WRITE;
	INSERT INTO `Users` VALUES (1,'admin@gmail.com','$2b$10$QhxqgCLAxIL7XKVDrk4NAOPyqastfT.4Nxzn5hEmRCF9evwVOa0Qy','0182654321','jdksafhkljdshfsdjahfQuận ksdjfkladshflkjasdjklfhlasdkjf','2024-11-06 11:22:22.478087','2024-11-06 20:07:10.476000',0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AZ21haWwuY29tIiwiYWRkcmVzcyI6Ik5ldyBBZGRyZXNzIiwicm9sZSI6InVzZXIiLCJpYXQiOjE3MzA4OTgzMjAsImV4cCI6MTczMTUwMzEyMH0.2Pmh6en5ET5thn4M0aVSnMNpQiwTozx6QIMxE8wspEY','John Doe'),(2,'user1@example.com','password1','0123456789','Hanoi','2024-11-06 11:35:58.183887','2024-11-06 11:35:58.183887',0,NULL,NULL),(3,'user2@example.com','password2','0987654321','Ho Chi Minh','2024-11-06 11:35:58.183887','2024-11-06 11:35:58.183887',0,NULL,NULL),(4,'user3@example.com','password3','0123123123','Da Nang','2024-11-06 11:35:58.183887','2024-11-06 11:35:58.183887',0,NULL,NULL),(5,'user4@example.com','password4','0981234567','Can Tho','2024-11-06 11:35:58.183887','2024-11-06 11:35:58.183887',0,NULL,NULL),(6,'user5@example.com','password5','0912345678','Hai Phong','2024-11-06 11:35:58.183887','2024-11-06 11:35:58.183887',0,NULL,NULL),(7,'adminha@gmail.com','$2b$10$tYpX6RJDq9AVejVIZbIZHuX0PNF8s9kNqhH30v9QlDDVl0ktC511.','0328746382221','jdksafhkljdshfsdjahfQuận ksdjfkladshflkjasdjklfhlasdkjf','2024-11-06 13:11:14.882520','2024-11-06 13:11:14.882520',0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjcsImVtYWlsIjoiYW1kaW5oYUBnbWFpbC5jb20iLCJhZGRyZXNzIjpudWxsLCJyb2xlIjoidXNlciIsImlhdCI6MTczMDg5ODk3NCwiZXhwIjoxNzMxNTAzNzc0fQ.hbqcJsTBYUUBjUJ4cJjYqsXthEYgMHPAEJE70t4RNHk',NULL),(8,'nguyenvu@gmail.com','$2b$09$3EZBsHWwUJNPjbwzc2vbsuHZLOq03UbFT54zsS7IX2u3NmTgfFTfS','0328746382221',NULL,'2024-11-06 14:32:48.929002','2024-11-06 14:32:48.929002',0,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjgsImVtYWlsIjoibmd1eWVudnVAZ21haWwuY29tIiwiYWRkcmVzcyI6bnVsbCwicm9sZSI6InVzZXIiLCJpYXQiOjE3MzA5MDQyNTQsImV4cCI6MTczMTUwOTA1NH0.gtlnUWZ4p7QATOj3zX7y9eMqA3R6shEhdVVK8sxCuY8',NULL);
	UNLOCK TABLES;


	-- Dump completed on 2024-11-08 11:38:03
